#!/usr/bin/env python

# Just prints standard out and sleeps for 10 seconds.
import sys
import time
print("Procesando " + sys.stdin.readlines()[0])
time.sleep(10)
